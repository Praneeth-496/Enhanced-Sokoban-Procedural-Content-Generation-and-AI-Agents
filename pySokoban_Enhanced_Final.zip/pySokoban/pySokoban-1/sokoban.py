# Name: pySokoban
# Description: A sokoban implementation using python & pyGame
# Author: Kazantzakis Nikos <kazantzakisnikos@gmail.com>
# Date: 2015
# Last Modified: 31-03-2016
# Significantly modified for PCG integration and theme selection by Manus AI Agent: May 14 2025

import pygame
import sys
import os # For path joining
from Environment import Environment
from Level import Level
import pcg_generator # Import the PCG module

# --- Global Variables ---
myEnvironment = None
myLevel = None
available_themes = ["default", "ksokoban", "soft"] # List of available themes
current_theme_index = 0
theme = available_themes[current_theme_index]
current_level_set_or_difficulty = "original" # Can be 'original', 'easy', 'medium', 'hard'
current_level_num = 1
target_found = False # Tracks if player was on a target before moving
hint_step_index = 0
screen_width, screen_height = 800, 600 # Default, will be updated by Environment

def draw_text(surface, text, position, font_size=20, color=(255, 255, 255)):
    font = pygame.font.Font(None, font_size) # Use default system font
    text_surface = font.render(text, True, color)
    surface.blit(text_surface, position)

def drawLevel(matrix_to_draw):
    global myEnvironment, myLevel, theme, screen_width, screen_height, hint_step_index
    if not myEnvironment or not myLevel:
        print("Error: Environment or Level not initialized for drawing.")
        return

    # Load level images based on the current theme
    try:
        wall_img_path = os.path.join(myEnvironment.getPath(), 'themes', theme, 'images', 'wall.png')
        box_img_path = os.path.join(myEnvironment.getPath(), 'themes', theme, 'images', 'box.png')
        box_on_target_img_path = os.path.join(myEnvironment.getPath(), 'themes', theme, 'images', 'box_on_target.png')
        space_img_path = os.path.join(myEnvironment.getPath(), 'themes', theme, 'images', 'space.png')
        target_img_path = os.path.join(myEnvironment.getPath(), 'themes', theme, 'images', 'target.png')
        player_img_path = os.path.join(myEnvironment.getPath(), 'themes', theme, 'images', 'player.png')

        wall = pygame.image.load(wall_img_path).convert()
        box = pygame.image.load(box_img_path).convert()
        box_on_target = pygame.image.load(box_on_target_img_path).convert()
        space = pygame.image.load(space_img_path).convert()
        target = pygame.image.load(target_img_path).convert()
        player = pygame.image.load(player_img_path).convert()
    except pygame.error as e:
        print(f"Error loading theme images for theme '{theme}': {e}")
        # Fallback to simple color rendering or exit
        myEnvironment.screen.fill((0,0,0))
        draw_text(myEnvironment.screen, f"Error: Failed to load theme '{theme}'. Check console.", (50, 50), 24)
        pygame.display.update()
        return

    level_width_tiles, level_height_tiles = myLevel.getSize()
    if level_width_tiles == 0 or level_height_tiles == 0:
        print("Error: Level size is zero.")
        myEnvironment.screen.fill((0,0,0))
        draw_text(myEnvironment.screen, "Error: Level data missing or corrupt.", (50, 50))
        pygame.display.update()
        return
        
    hud_height = 80 # Increased HUD height for more info
    drawable_height = screen_height - hud_height

    img_size_w = screen_width // level_width_tiles
    img_size_h = drawable_height // level_height_tiles
    new_image_size = min(img_size_w, img_size_h, 36) 
    if new_image_size < 10: new_image_size = 10

    if new_image_size != 36: 
        wall = pygame.transform.scale(wall, (new_image_size, new_image_size))
        box = pygame.transform.scale(box, (new_image_size, new_image_size))
        box_on_target = pygame.transform.scale(box_on_target, (new_image_size, new_image_size))
        space = pygame.transform.scale(space, (new_image_size, new_image_size))
        target = pygame.transform.scale(target, (new_image_size, new_image_size))
        player = pygame.transform.scale(player, (new_image_size, new_image_size))

    images = {'#': wall, ' ': space, '$': box, '.': target, '@': player, '*': box_on_target, '+': player}
    
    myEnvironment.screen.fill((0,0,0))

    for r, row_val in enumerate(matrix_to_draw):
        for c, char_val in enumerate(row_val):
            if char_val in images:
                myEnvironment.screen.blit(images[char_val], (c * new_image_size, r * new_image_size))
            else:
                pygame.draw.rect(myEnvironment.screen, (255,0,255), (c*new_image_size, r*new_image_size, new_image_size, new_image_size))
    
    # Draw HUD
    draw_text(myEnvironment.screen, "Controls: Arrows (Move), U (Undo), R (Restart)", (10, screen_height - 75), 18)
    draw_text(myEnvironment.screen, "PCG Levels: 1 (Easy), 2 (Medium), 3 (Hard)", (10, screen_height - 55), 18)
    draw_text(myEnvironment.screen, "Actions: N (New Level), H (Hint), T (Cycle Theme)", (10, screen_height - 35), 18)
    
    current_theme_text = f"Theme: {theme.capitalize()}"
    draw_text(myEnvironment.screen, current_theme_text, (screen_width - 200, screen_height - 75), 18)

    if myLevel.is_pcg_level and myLevel.solution_path:
        total_hints = len(myLevel.solution_path)
        hint_progress = f"Hint: {hint_step_index}/{total_hints}"
        if hint_step_index >= total_hints and total_hints > 0:
            hint_progress = "All hints used"
        elif total_hints == 0:
            hint_progress = "No hints for this level"
        draw_text(myEnvironment.screen, hint_progress, (screen_width - 200, screen_height - 55), 18)

    pygame.display.update()

def movePlayer(direction):
    global myLevel, target_found, hint_step_index, screen_width, screen_height
    if not myLevel:
        return False # Indicate move was not made

    matrix = myLevel.getMatrix()
    myLevel.addToHistory(matrix)

    player_pos = myLevel.getPlayerPosition()
    if not player_pos:
        print("Error: Player position not found.")
        return False
    
    y, x = player_pos[1], player_pos[0]

    if direction == "L": dx, dy = -1, 0
    elif direction == "R": dx, dy = 1, 0
    elif direction == "U": dx, dy = 0, -1
    elif direction == "D": dx, dy = 0, 1
    else: return False

    next_x, next_y = x + dx, y + dy
    next_next_x, next_next_y = x + 2*dx, y + 2*dy

    if not (0 <= next_y < len(matrix) and 0 <= next_x < len(matrix[next_y])):
        myLevel.getLastMatrix() 
        return False

    current_player_char = matrix[y][x]
    destination_char = matrix[next_y][next_x]
    new_matrix = [list(row) for row in matrix]
    can_move = False

    if destination_char == ' ' or destination_char == '.':
        can_move = True
    elif destination_char == '$' or destination_char == '*':
        if not (0 <= next_next_y < len(matrix) and 0 <= next_next_x < len(matrix[next_next_y])):
            myLevel.getLastMatrix()
            return False
        
        char_beyond_box = matrix[next_next_y][next_next_x]
        if char_beyond_box == ' ' or char_beyond_box == '.':
            can_move = True
            new_matrix[next_next_y][next_next_x] = '*' if char_beyond_box == '.' else '$'
            new_matrix[next_y][next_x] = '+' if destination_char == '*' else '@'
        else:
            myLevel.getLastMatrix()
            return False
    else:
        myLevel.getLastMatrix()
        return False

    if can_move:
        new_matrix[next_y][next_x] = '+' if destination_char == '.' or (destination_char == '*' and new_matrix[next_y][next_x] == '@') else '@'
        new_matrix[y][x] = '.' if current_player_char == '+' else ' '
        myLevel.matrix = new_matrix
        drawLevel(myLevel.getMatrix())

        if myLevel.isSolved():
            myEnvironment.screen.fill((0,0,0))
            draw_text(myEnvironment.screen, "Level Completed!", (screen_width//2 - 100, screen_height//2 - 20), 30)
            pygame.display.update()
            pygame.time.wait(2000)
            if myLevel.is_pcg_level:
                initLevel(current_level_set_or_difficulty, is_pcg=True, new_pcg_level=True)
            else:
                global current_level_num
                current_level_num += 1
                try:
                    initLevel(current_level_set_or_difficulty, current_level_num)
                except Exception: 
                    print(f"No more levels in set {current_level_set_or_difficulty} or error loading. Resetting or choose PCG.")
                    initLevel("easy", is_pcg=True, new_pcg_level=True)
        return True # Move was successful
    return False # Move was not successful

def initLevel(level_source_or_difficulty, level_num_specifier=None, is_pcg=False, new_pcg_level=False):
    global myLevel, current_level_set_or_difficulty, current_level_num, hint_step_index
    hint_step_index = 0 # Reset hint index for new level

    if is_pcg:
        current_level_set_or_difficulty = level_source_or_difficulty
        print(f"Initializing PCG level: {current_level_set_or_difficulty}")
        generated_matrix, solution = pcg_generator.generate_level(current_level_set_or_difficulty)
        myLevel = Level(source=generated_matrix, level_specifier=current_level_set_or_difficulty, is_pcg=True, solution_path=solution)
    else:
        current_level_set_or_difficulty = level_source_or_difficulty
        current_level_num = level_num_specifier
        print(f"Initializing file level: {current_level_set_or_difficulty} - {current_level_num}")
        myLevel = Level(source=current_level_set_or_difficulty, level_specifier=current_level_num, is_pcg=False)

    if myLevel and myLevel.getMatrix():
        drawLevel(myLevel.getMatrix())
    else:
        print("Failed to initialize or load level.")
        myEnvironment.screen.fill((20,0,0))
        draw_text(myEnvironment.screen, "Error: Could not load level!", (50,50))
        pygame.display.update()
        pygame.time.wait(3000)
        pygame.quit()
        sys.exit()

def show_hint():
    global myLevel, hint_step_index
    if not myLevel or not myLevel.is_pcg_level or not myLevel.solution_path:
        print("Hint not available for this level.")
        drawLevel(myLevel.getMatrix()) # Redraw to update HUD if it says "No hints"
        return

    if hint_step_index < len(myLevel.solution_path):
        move = myLevel.solution_path[hint_step_index]
        print(f"Hint: Applying move {move} (Step {hint_step_index + 1}/{len(myLevel.solution_path)})")
        
        # Try to apply the move
        move_successful = movePlayer(move)
        
        if move_successful:
            hint_step_index += 1 # Increment to show next step next time ONLY if move was made
        else:
            # If the move failed, it might be because the player has deviated from the solution path
            # In this case, we need to regenerate a solution from the current state
            print("Hint move could not be applied. Regenerating solution from current state...")
            regenerate_solution_from_current_state()
            
        drawLevel(myLevel.getMatrix()) # Redraw to show hint progress in HUD and new state
    else:
        # If we've reached the end of the solution path but the level isn't solved,
        # we need to regenerate a solution from the current state
        if not myLevel.isSolved():
            print("End of current solution path reached but level not solved. Regenerating solution...")
            regenerate_solution_from_current_state()
        else:
            print(f"End of hints. All {len(myLevel.solution_path)} steps of the solution have been shown.")
        
        drawLevel(myLevel.getMatrix()) # Redraw to update HUD

def regenerate_solution_from_current_state():
    """Regenerate a solution path from the current game state"""
    global myLevel, hint_step_index
    
    if not myLevel or not myLevel.is_pcg_level:
        return
    
    # Get the current matrix state
    current_matrix = myLevel.getMatrix()
    
    # Use the solver to find a new solution from the current state
    new_solution = pcg_generator.solve_sokoban_bfs(current_matrix)
    
    if new_solution:
        print(f"New solution found from current state with {len(new_solution)} steps.")
        myLevel.solution_path = new_solution
        hint_step_index = 0  # Reset hint index for the new solution
        
        # Apply the first hint of the new solution immediately
        if hint_step_index < len(myLevel.solution_path):
            move = myLevel.solution_path[hint_step_index]
            print(f"Hint: Applying move {move} (Step {hint_step_index + 1}/{len(myLevel.solution_path)})")
            move_successful = movePlayer(move)
            if move_successful:
                hint_step_index += 1
    else:
        print("Could not find a solution from the current state. The level might be unsolvable from here.")
        # Optionally, we could reset the level here if it's unsolvable

def cycle_theme():
    global theme, current_theme_index, available_themes, myLevel
    current_theme_index = (current_theme_index + 1) % len(available_themes)
    theme = available_themes[current_theme_index]
    print(f"Theme changed to: {theme}")
    if myLevel and myLevel.getMatrix():
        drawLevel(myLevel.getMatrix())

# --- Main Game Setup and Loop ---
if __name__ == '__main__':
    pygame.init()
    myEnvironment = Environment()
    screen_width, screen_height = myEnvironment.size # Get actual screen size
    pygame.display.set_caption("pySokoban - PCG Enhanced")

    initLevel("original", 1) # Start with a classic level

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT: movePlayer("L")
                elif event.key == pygame.K_RIGHT: movePlayer("R")
                elif event.key == pygame.K_UP: movePlayer("U")
                elif event.key == pygame.K_DOWN: movePlayer("D")
                elif event.key == pygame.K_u: 
                    if myLevel:
                        undone_matrix = myLevel.getLastMatrix()
                        if undone_matrix: # Check if history is not empty
                           drawLevel(undone_matrix)
                           # If hint_step_index was tied to history, it would need adjustment here.
                           # For now, undo doesn't rewind hint_step_index, player can explore.
                elif event.key == pygame.K_r:
                    if myLevel:
                        myLevel.resetLevel()
                        hint_step_index = 0 # Reset hints on level restart
                        drawLevel(myLevel.getMatrix())
                elif event.key == pygame.K_1:
                    initLevel("easy", is_pcg=True, new_pcg_level=True)
                elif event.key == pygame.K_2:
                    initLevel("medium", is_pcg=True, new_pcg_level=True)
                elif event.key == pygame.K_3:
                    initLevel("hard", is_pcg=True, new_pcg_level=True)
                elif event.key == pygame.K_n:
                    if myLevel and myLevel.is_pcg_level:
                        initLevel(current_level_set_or_difficulty, is_pcg=True, new_pcg_level=True)
                    else:
                        initLevel("easy", is_pcg=True, new_pcg_level=True)
                elif event.key == pygame.K_h:
                    show_hint()
                elif event.key == pygame.K_t:
                    cycle_theme()
                elif event.key == pygame.K_ESCAPE:
                    running = False
        
        pygame.time.wait(10)

    pygame.quit()
    sys.exit()
