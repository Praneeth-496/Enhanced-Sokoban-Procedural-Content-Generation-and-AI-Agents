# pcg_generator.py

import random
import collections
import copy # For deep copying level states

# Define level elements
WALL = '#'
FLOOR = ' '
PLAYER = '@'
BOX = '$'
GOAL = '.'
BOX_ON_GOAL = '*'
PLAYER_ON_GOAL = '+' # Player on a goal square

# --- Fallback Levels Pool ---
# Enhanced fallback levels for medium and hard difficulties
FALLBACK_LEVELS_POOL = [
    # Easy fallbacks
    (
        [
            ['#','#','#','#','#'],
            ['#','@',' ',' ','#'],
            ['#',' ','$','.','#'],
            ['#',' ',' ',' ','#'],
            ['#','#','#','#','#']
        ],
        ['D', 'R'] 
    ),
    (
        [
            ['#','#','#','#','#','#'],
            ['#','@',' ','$','.','#'],
            ['#',' ',' ',' ',' ','#'],
            ['#','#','#','#','#','#']
        ],
        ['R', 'R']
    ),
    # Medium fallbacks with more complex layouts
    (
        [
            ['#','#','#','#','#','#','#','#'],
            ['#',' ',' ',' ',' ',' ',' ','#'],
            ['#',' ','#','#','#','#',' ','#'],
            ['#',' ','#','.','.','.','$','#'],
            ['#',' ','#','$','$','@',' ','#'],
            ['#',' ',' ',' ',' ',' ',' ','#'],
            ['#','#','#','#','#','#','#','#']
        ],
        ['L', 'U', 'U', 'R', 'R', 'D', 'L', 'L', 'U', 'R', 'R', 'D', 'D', 'L', 'U', 'L', 'U', 'R']
    ),
    (
        [
            ['#','#','#','#','#','#','#'],
            ['#',' ',' ',' ',' ',' ','#'],
            ['#',' ','$','#','$',' ','#'],
            ['#','.','@','#','.','$','#'],
            ['#',' ','.','#',' ',' ','#'],
            ['#','#','#','#','#','#','#']
        ],
        ['R', 'U', 'L', 'D', 'R', 'R', 'U', 'L', 'L', 'D', 'R', 'U', 'R', 'U', 'L', 'L', 'D', 'R', 'R']
    ),
    # Hard fallbacks with complex layouts and more boxes
    (
        [
            ['#','#','#','#','#','#','#','#','#'],
            ['#',' ',' ',' ','#',' ',' ',' ','#'],
            ['#',' ','$',' ','#',' ','$',' ','#'],
            ['#',' ','$',' ',' ',' ','$',' ','#'],
            ['#','#','#','.','@','.','#','#','#'],
            ['#',' ','$',' ',' ',' ','$',' ','#'],
            ['#',' ','$',' ','#',' ','$',' ','#'],
            ['#',' ',' ',' ','#',' ',' ',' ','#'],
            ['#','#','#','#','#','#','#','#','#']
        ],
        ['L', 'U', 'U', 'R', 'R', 'D', 'D', 'L', 'U', 'L', 'U', 'R', 'R', 'D', 'D', 'L', 'U', 'U', 'L', 'D', 'D', 'R', 'U', 'U', 'R', 'D', 'D', 'L', 'U', 'U', 'L', 'D', 'D', 'R', 'U', 'R', 'U', 'L', 'L', 'D', 'R', 'R', 'U', 'L', 'L', 'D', 'R', 'R']
    ),
    (
        [
            ['#','#','#','#','#','#','#','#','#'],
            ['#',' ',' ',' ',' ',' ',' ',' ','#'],
            ['#',' ','#','#','#','#','#',' ','#'],
            ['#',' ','#','.','.','.','#',' ','#'],
            ['#',' ','#','$','$','$','#',' ','#'],
            ['#',' ','#','@','$','.','#',' ','#'],
            ['#',' ','#','#','#','#','#',' ','#'],
            ['#',' ',' ',' ',' ',' ',' ',' ','#'],
            ['#','#','#','#','#','#','#','#','#']
        ],
        ['U', 'U', 'L', 'D', 'D', 'R', 'U', 'U', 'R', 'D', 'D', 'L', 'U', 'U', 'R', 'R', 'D', 'L', 'L', 'U', 'R', 'R', 'D', 'L', 'D', 'L', 'U', 'U', 'R', 'D', 'R', 'U', 'L', 'L', 'D', 'R', 'R']
    )
]

# --- Helper Functions for Solver and Generator ---

def get_player_and_boxes_positions(matrix):
    player_pos = None
    box_positions = []
    for r, row in enumerate(matrix):
        for c, char in enumerate(row):
            if char == PLAYER or char == PLAYER_ON_GOAL:
                player_pos = (r, c)
            elif char == BOX or char == BOX_ON_GOAL:
                box_positions.append((r, c))
    return player_pos, frozenset(sorted(box_positions))

def get_goal_positions(matrix):
    goal_positions = []
    for r, row in enumerate(matrix):
        for c, char in enumerate(row):
            if char == GOAL or char == BOX_ON_GOAL or char == PLAYER_ON_GOAL:
                goal_positions.append((r, c))
    return frozenset(goal_positions)

def is_level_solved(box_positions, goal_positions):
    if not box_positions or not goal_positions: 
        return False
    return box_positions == goal_positions

# --- Solvability Checker (BFS) ---

def solve_sokoban_bfs(initial_matrix):
    initial_player_pos, initial_box_positions = get_player_and_boxes_positions(initial_matrix)
    goal_positions = get_goal_positions(initial_matrix)

    if not initial_player_pos or not initial_box_positions or not goal_positions:
        return None
    
    if is_level_solved(initial_box_positions, goal_positions):
        return [] 

    queue = collections.deque([(initial_matrix, [])]) 
    visited = set([(initial_player_pos, initial_box_positions)])

    max_iterations = 100000 # Increased for potentially harder levels
    iterations = 0

    while queue and iterations < max_iterations:
        iterations += 1
        current_matrix_tuple, current_path = queue.popleft()
        current_matrix = [list(row) for row in current_matrix_tuple]
        current_player_pos, current_box_positions_fs = get_player_and_boxes_positions(current_matrix)
        if not current_player_pos: continue

        for dr, dc, move_char in [(-1, 0, 'U'), (1, 0, 'D'), (0, -1, 'L'), (0, 1, 'R')]:
            current_box_positions_list = list(current_box_positions_fs)
            new_player_r, new_player_c = current_player_pos[0] + dr, current_player_pos[1] + dc
            next_state_matrix = [list(row) for row in current_matrix]

            if not (0 <= new_player_r < len(next_state_matrix) and 0 <= new_player_c < len(next_state_matrix[0])):
                continue

            char_at_new_player_pos = next_state_matrix[new_player_r][new_player_c]
            player_becomes_char = PLAYER
            valid_move = False
            moved_box_info = None

            if char_at_new_player_pos == FLOOR:
                valid_move = True
            elif char_at_new_player_pos == GOAL:
                player_becomes_char = PLAYER_ON_GOAL
                valid_move = True
            elif char_at_new_player_pos == BOX or char_at_new_player_pos == BOX_ON_GOAL:
                box_original_char = char_at_new_player_pos
                pushed_box_next_r, pushed_box_next_c = new_player_r + dr, new_player_c + dc

                if not (0 <= pushed_box_next_r < len(next_state_matrix) and 0 <= pushed_box_next_c < len(next_state_matrix[0])):
                    continue 
                
                char_beyond_pushed_box = next_state_matrix[pushed_box_next_r][pushed_box_next_c]
                if char_beyond_pushed_box == WALL or char_beyond_pushed_box == BOX or char_beyond_pushed_box == BOX_ON_GOAL:
                    continue
                
                valid_move = True
                next_state_matrix[pushed_box_next_r][pushed_box_next_c] = BOX_ON_GOAL if char_beyond_pushed_box == GOAL else BOX
                moved_box_info = ((new_player_r, new_player_c), (pushed_box_next_r, pushed_box_next_c))
                player_becomes_char = PLAYER_ON_GOAL if box_original_char == BOX_ON_GOAL else PLAYER
            
            elif char_at_new_player_pos == WALL:
                continue

            if valid_move:
                next_state_matrix[new_player_r][new_player_c] = player_becomes_char
                original_player_char_at_old_pos = current_matrix[current_player_pos[0]][current_player_pos[1]]
                next_state_matrix[current_player_pos[0]][current_player_pos[1]] = GOAL if original_player_char_at_old_pos == PLAYER_ON_GOAL else FLOOR
                
                final_new_box_positions_list = list(current_box_positions_list)
                if moved_box_info:
                    old_box_pos, new_box_pos = moved_box_info
                    if old_box_pos in final_new_box_positions_list:
                        final_new_box_positions_list.remove(old_box_pos)
                    final_new_box_positions_list.append(new_box_pos)
                
                final_new_box_positions_fs = frozenset(sorted(final_new_box_positions_list))
                new_player_actual_pos_tuple = (new_player_r, new_player_c)

                if (new_player_actual_pos_tuple, final_new_box_positions_fs) not in visited:
                    if is_level_solved(final_new_box_positions_fs, goal_positions):
                        return current_path + [move_char]
                    
                    visited.add((new_player_actual_pos_tuple, final_new_box_positions_fs))
                    queue.append((tuple(map(tuple, next_state_matrix)), current_path + [move_char]))
    return None

# --- Level Generation Logic ---

def create_empty_level(rows, cols):
    return [[FLOOR for _ in range(cols)] for _ in range(rows)]

def generate_internal_walls_random_walk(matrix, num_walks, walk_length_factor):
    rows, cols = len(matrix), len(matrix[0])
    if rows <= 2 or cols <= 2: return

    for _ in range(num_walks):
        start_r, start_c = random.randint(1, rows-2), random.randint(1, cols-2)
        current_r, current_c = start_r, start_c
        max_walk_len = int((rows + cols) * walk_length_factor)

        for _ in range(max_walk_len):
            if 1 <= current_r < rows-1 and 1 <= current_c < cols-1:
                if matrix[current_r][current_c] == FLOOR: 
                    matrix[current_r][current_c] = WALL
            else: break

            dr, dc = random.choice([(-1,0), (1,0), (0,-1), (0,1)])
            next_r, next_c = current_r + dr, current_c + dc

            if 1 <= next_r < rows-1 and 1 <= next_c < cols-1:
                current_r, current_c = next_r, next_c
            else:
                current_r, current_c = random.randint(1, rows-2), random.randint(1, cols-2)

def generate_room_based_layout(matrix, difficulty):
    """Generate a room-based layout with corridors connecting rooms"""
    rows, cols = len(matrix), len(matrix[0])
    if rows <= 6 or cols <= 6:
        return
    
    # Create outer walls
    for r in range(rows):
        matrix[r][0] = WALL
        matrix[r][cols-1] = WALL
    for c in range(cols):
        matrix[0][c] = WALL
        matrix[rows-1][c] = WALL
    
    # Determine number of rooms based on difficulty
    if difficulty == "medium":
        num_rooms = random.randint(2, 3)
    else:  # hard
        num_rooms = random.randint(3, 4)
    
    # Create rooms
    rooms = []
    for _ in range(num_rooms):
        # Room size varies with difficulty
        if difficulty == "medium":
            room_height = random.randint(3, 4)
            room_width = random.randint(3, 4)
        else:  # hard
            room_height = random.randint(3, 5)
            room_width = random.randint(3, 5)
        
        # Find a valid position for the room
        attempts = 0
        while attempts < 50:
            top_left_r = random.randint(1, rows - room_height - 1)
            top_left_c = random.randint(1, cols - room_width - 1)
            
            # Check if this room overlaps with existing rooms
            overlap = False
            for r, c, h, w in rooms:
                if (top_left_r <= r + h and r <= top_left_r + room_height and
                    top_left_c <= c + w and c <= top_left_c + room_width):
                    overlap = True
                    break
            
            if not overlap:
                rooms.append((top_left_r, top_left_c, room_height, room_width))
                break
            
            attempts += 1
    
    # Create room walls
    for room_r, room_c, room_h, room_w in rooms:
        for r in range(room_r, room_r + room_h):
            matrix[r][room_c] = WALL
            matrix[r][room_c + room_w - 1] = WALL
        for c in range(room_c, room_c + room_w):
            matrix[room_r][c] = WALL
            matrix[room_r + room_h - 1][c] = WALL
    
    # Create doorways in rooms
    for room_r, room_c, room_h, room_w in rooms:
        # Choose random walls to put doorways
        num_doorways = random.randint(1, 2)
        for _ in range(num_doorways):
            wall_type = random.choice(['top', 'bottom', 'left', 'right'])
            
            if wall_type == 'top':
                door_c = random.randint(room_c + 1, room_c + room_w - 2)
                matrix[room_r][door_c] = FLOOR
            elif wall_type == 'bottom':
                door_c = random.randint(room_c + 1, room_c + room_w - 2)
                matrix[room_r + room_h - 1][door_c] = FLOOR
            elif wall_type == 'left':
                door_r = random.randint(room_r + 1, room_r + room_h - 2)
                matrix[door_r][room_c] = FLOOR
            elif wall_type == 'right':
                door_r = random.randint(room_r + 1, room_r + room_h - 2)
                matrix[door_r][room_c + room_w - 1] = FLOOR
    
    # Add some random internal walls for complexity
    if difficulty == "medium":
        num_walks = random.randint(2, 3)
        walk_length_factor = random.uniform(0.15, 0.25)
    else:  # hard
        num_walks = random.randint(3, 5)
        walk_length_factor = random.uniform(0.2, 0.3)
    
    generate_internal_walls_random_walk(matrix, num_walks, walk_length_factor)

def place_objects(matrix, num_boxes, rows, cols, difficulty):
    occupied_cells = set()
    player_pos_final = None
    box_pos_final = []
    goal_pos_final = []

    def find_empty_floor_cell(current_matrix, occupied):
        possible_cells = []
        for r_idx in range(1, rows - 1):
            for c_idx in range(1, cols - 1):
                if current_matrix[r_idx][c_idx] == FLOOR and (r_idx, c_idx) not in occupied:
                    possible_cells.append((r_idx, c_idx))
        if not possible_cells: return None
        return random.choice(possible_cells)
    
    # For medium and hard levels, try to place boxes and goals in more challenging positions
    if difficulty in ["medium", "hard"]:
        # First place the player
        player_pos = find_empty_floor_cell(matrix, occupied_cells)
        if player_pos:
            matrix[player_pos[0]][player_pos[1]] = PLAYER
            occupied_cells.add(player_pos)
            player_pos_final = player_pos
        else: return False
        
        # For medium/hard, try to place goals in corners or near walls
        for _ in range(num_boxes):
            # Find cells that are near walls or in corners
            corner_or_wall_cells = []
            for r_idx in range(1, rows - 1):
                for c_idx in range(1, cols - 1):
                    if matrix[r_idx][c_idx] == FLOOR and (r_idx, c_idx) not in occupied_cells:
                        wall_count = 0
                        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                            if matrix[r_idx + dr][c_idx + dc] == WALL:
                                wall_count += 1
                        if wall_count >= (1 if difficulty == "medium" else 2):
                            corner_or_wall_cells.append((r_idx, c_idx))
            
            goal_pos = None
            if corner_or_wall_cells and random.random() < 0.7:  # 70% chance to use a corner/wall cell
                goal_pos = random.choice(corner_or_wall_cells)
            else:
                goal_pos = find_empty_floor_cell(matrix, occupied_cells)
            
            if goal_pos:
                matrix[goal_pos[0]][goal_pos[1]] = GOAL
                occupied_cells.add(goal_pos)
                goal_pos_final.append(goal_pos)
            else: return False
        
        # Place boxes with some distance from goals to make it more challenging
        for _ in range(num_boxes):
            box_pos = find_empty_floor_cell(matrix, occupied_cells)
            if box_pos:
                matrix[box_pos[0]][box_pos[1]] = BOX
                occupied_cells.add(box_pos)
                box_pos_final.append(box_pos)
            else: return False
    else:
        # Original placement logic for easy levels
        player_pos = find_empty_floor_cell(matrix, occupied_cells)
        if player_pos:
            matrix[player_pos[0]][player_pos[1]] = PLAYER
            occupied_cells.add(player_pos)
            player_pos_final = player_pos
        else: return False

        for _ in range(num_boxes):
            goal_pos = find_empty_floor_cell(matrix, occupied_cells)
            if goal_pos:
                matrix[goal_pos[0]][goal_pos[1]] = GOAL
                occupied_cells.add(goal_pos)
                goal_pos_final.append(goal_pos)
            else: return False

        for _ in range(num_boxes):
            box_pos = find_empty_floor_cell(matrix, occupied_cells)
            if box_pos:
                matrix[box_pos[0]][box_pos[1]] = BOX
                occupied_cells.add(box_pos)
                box_pos_final.append(box_pos)
            else: return False
    
    # Check reachability
    if player_pos_final:
        q = collections.deque([player_pos_final])
        reachable_floor = {player_pos_final}
        visited_for_reachability = {player_pos_final}
        while q:
            r,c = q.popleft()
            for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                nr, nc = r+dr, c+dc
                if 0 <= nr < rows and 0 <= nc < cols and matrix[nr][nc] != WALL and (nr,nc) not in visited_for_reachability:
                    if matrix[nr][nc] == FLOOR or matrix[nr][nc] == GOAL:
                         reachable_floor.add((nr,nc))
                         q.append((nr,nc))
                         visited_for_reachability.add((nr,nc))
        
        all_objects_potentially_reachable = True
        for pos_list in [box_pos_final, goal_pos_final]:
            for pos in pos_list:
                is_adj_to_reachable = False
                if pos in reachable_floor: # Object itself is on reachable floor
                    is_adj_to_reachable = True
                else: # Check adjacent cells
                    for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                        if (pos[0]+dr, pos[1]+dc) in reachable_floor:
                            is_adj_to_reachable = True; break
                if not is_adj_to_reachable:
                    all_objects_potentially_reachable = False; break
            if not all_objects_potentially_reachable: break
        if not all_objects_potentially_reachable:
            return False
    return True

def generate_raw_level(rows, cols, num_boxes, difficulty):
    matrix = create_empty_level(rows, cols)
    for r in range(rows):
        matrix[r][0] = WALL; matrix[r][cols-1] = WALL
    for c in range(cols):
        matrix[0][c] = WALL; matrix[rows-1][c] = WALL

    # Use different generation strategies based on difficulty
    if difficulty == "easy":
        # Simple random walk for easy levels
        num_walks, walk_length_factor = random.randint(1,2), random.uniform(0.1, 0.15)
        generate_internal_walls_random_walk(matrix, num_walks, walk_length_factor)
    else:
        # Room-based layout for medium and hard levels
        generate_room_based_layout(matrix, difficulty)
    
    if not place_objects(matrix, num_boxes, rows, cols, difficulty):
        return None
    return matrix

# Track used fallbacks to avoid repetition
last_fallback_indices = {"easy": -1, "medium": -1, "hard": -1}

def generate_level(difficulty):
    global last_fallback_indices
    print(f"Attempting to generate level for difficulty: {difficulty}")

    # Difficulty-specific parameters based on research and todo.md
    if difficulty == "easy":
        rows, cols = random.choice([(7,7), (8,8), (9,9)])
        num_boxes = random.randint(1, 2)
        min_sol, max_sol = 5, 20
        fallback_indices = [0, 1]  # Indices of easy fallbacks
    elif difficulty == "medium":
        rows, cols = random.choice([(9,9), (10,10), (11,11), (12,12)])
        num_boxes = random.randint(3, 4)
        min_sol, max_sol = 15, 45
        fallback_indices = [2, 3]  # Indices of medium fallbacks
    else: # hard
        rows, cols = random.choice([(11,11), (12,12), (13,13), (14,14), (15,15)])
        num_boxes = random.randint(4, 6)  # Increased max boxes for hard
        min_sol, max_sol = 40, 100  # Increased max solution length for hard
        fallback_indices = [4, 5]  # Indices of hard fallbacks

    # For testing purposes, use a much lower attempt limit
    max_attempts = 50  # Reduced for faster testing
    
    for attempt in range(max_attempts):
        if (attempt + 1) % 10 == 0:
             print(f"Generation attempt {attempt + 1}/{max_attempts} for {difficulty} level...")

        level_matrix_raw = generate_raw_level(rows, cols, num_boxes, difficulty)
        if level_matrix_raw is None: continue

        level_matrix_for_solver = copy.deepcopy(level_matrix_raw)
        solution_path = solve_sokoban_bfs(level_matrix_for_solver)

        if solution_path is not None and (min_sol <= len(solution_path) <= max_sol):
            print(f"Solvable level generated for {difficulty} with solution length {len(solution_path)}.")
            return level_matrix_raw, solution_path

    print(f"Failed to generate a suitable level for {difficulty} after {max_attempts} attempts. Using fallback.")
    
    # Select a fallback that hasn't been used recently for this difficulty
    possible_indices = [i for i in fallback_indices if i != last_fallback_indices[difficulty]]
    if not possible_indices: 
        chosen_fallback_index = fallback_indices[0]
    else:
        chosen_fallback_index = random.choice(possible_indices)
    
    last_fallback_indices[difficulty] = chosen_fallback_index
    fallback_matrix_template, fallback_solution_template = FALLBACK_LEVELS_POOL[chosen_fallback_index]
    
    fallback_matrix = copy.deepcopy(fallback_matrix_template)
    fallback_solution = list(fallback_solution_template)

    return fallback_matrix, fallback_solution

if __name__ == '__main__':
    for diff_level in ["easy", "medium", "hard"]:
        print(f"\n--- Testing {diff_level} level generation (will try multiple fallbacks if needed) ---")
        for i in range(2): # Test generation twice per difficulty for quick check
            print(f"Test run {i+1} for {diff_level}")
            level_data, sol_path = generate_level(diff_level)
            if level_data:
                for r_idx, r_val in enumerate(level_data):
                    print("" + "".join(r_val))
                print(f"  Solution path length: {len(sol_path) if sol_path else 'None'}")
                for idx, fallback in enumerate(FALLBACK_LEVELS_POOL):
                    if level_data == fallback[0] and sol_path == fallback[1]:
                        print(f"  (Used fallback index: {idx})")
                        break
            else:
                print(f"  Could not generate {diff_level} level.")
