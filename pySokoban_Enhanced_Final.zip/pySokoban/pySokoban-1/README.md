# Enhanced pySokoban with PCG and Heuristic Agent

This is an enhanced version of pySokoban with the following features:

1. **Procedural Content Generation (PCG)** for levels with three difficulty settings:
   - Easy: Simpler layouts with 1-2 boxes and shorter solutions
   - Medium: More complex layouts with 3-4 boxes and medium-length solutions
   - Hard: Challenging layouts with 4-6 boxes and longer solutions

2. **Complete Hint System** that provides step-by-step solutions:
   - Shows the next move in the solution path
   - Regenerates solutions if the player deviates from the original path
   - Continues providing hints until the level is solved

3. **Heuristic Agent** that can automatically solve any PCG-generated level:
   - Runs in a separate file (`heuristic_agent.py`)
   - Automatically selects and solves random levels
   - Continues solving levels until stopped

## How to Run

### Main Game

```bash
python3 sokoban.py
```

### Controls
- **Arrow Keys**: Move the player
- **U**: Undo move
- **R**: Restart level
- **1, 2, 3**: Generate Easy, Medium, Hard PCG level
- **N**: Generate new level of current difficulty
- **H**: Show hint (next move in solution)
- **T**: Cycle through themes
- **ESC**: Quit game

### Heuristic Agent

```bash
python3 heuristic_agent.py
```

The heuristic agent will automatically:
1. Generate a random level
2. Find a solution
3. Play through the solution
4. Generate a new level and repeat

## Implementation Details

### PCG System
- Uses a hybrid approach combining constructive and search-based methods
- Room-based layouts for medium and hard difficulties
- Random walk wall generation for easy levels
- Strategic placement of boxes and goals based on difficulty
- BFS solver to verify solvability and find solution paths
- Fallback levels when generation fails after multiple attempts

### Hint System
- Pre-calculated solution paths for each generated level
- Dynamic solution regeneration if player deviates from the path
- Complete step-by-step guidance until level completion

### Heuristic Agent
- Uses the same BFS solver from the PCG system
- Automatically applies solution moves with a delay
- Handles level completion and new level generation

## Notes
- For production use, you may want to increase the `max_attempts` value in `pcg_generator.py` to reduce fallback frequency
- The current testing configuration uses a lower attempt limit for faster validation
