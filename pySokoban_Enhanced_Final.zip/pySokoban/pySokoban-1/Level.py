import os
import copy

class Level:

    matrix = []
    matrix_history = []
    original_matrix = [] # To store the initial state of the level for restarts
    solution_path = [] # To store the solution for hints
    is_pcg_level = False

    def __init__(self, source, level_specifier=None, is_pcg=False, solution_path=None):
        """Initializes a level.

        Args:
            source (str or list): If not is_pcg, this is the level set name (e.g., "original").
                                  If is_pcg, this is the generated level matrix.
            level_specifier (int or str): If not is_pcg, this is the level number.
                                          If is_pcg, this can be the difficulty string (e.g., "easy").
            is_pcg (bool): True if the level is procedurally generated.
            solution_path (list, optional): The solution path for PCG levels.
        """
        del self.matrix[:]
        del self.matrix_history[:]
        self.is_pcg_level = is_pcg

        if is_pcg:
            self.matrix = copy.deepcopy(source) # source is the generated matrix
            if solution_path:
                self.solution_path = solution_path
            else:
                self.solution_path = [] # Default to empty if not provided
        else:
            # Existing file loading logic
            level_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'levels', source, 'level' + str(level_specifier))
            try:
                with open(level_path, 'r') as f:
                    for row in f.read().splitlines():
                        self.matrix.append(list(row))
            except FileNotFoundError:
                print(f"Error: Level file not found at {level_path}")
                # Fallback to a very simple default level or raise error
                self.matrix = [
                    ['#', '#', '#', '#', '#'],
                    ['#', ' ', '@', ' ', '#'],
                    ['#', ' ', '$', '.', '#'],
                    ['#', ' ', ' ', ' ', '#'],
                    ['#', '#', '#', '#', '#']
                ]
        
        self.original_matrix = copy.deepcopy(self.matrix) # Store for restarting the same level

    def __del__(self):
        "Destructor to make sure object shuts down, etc."
        pass

    def getMatrix(self):
        return self.matrix

    def addToHistory(self, matrix_state):
        self.matrix_history.append(copy.deepcopy(matrix_state))

    def getLastMatrix(self):
        if len(self.matrix_history) > 0:
            lastMatrix = self.matrix_history.pop()
            self.matrix = lastMatrix
            return lastMatrix
        else:
            # If no history, return current matrix (or original if preferred for undo at start)
            return self.matrix

    def getPlayerPosition(self):
        for r, row_val in enumerate(self.matrix):
            for c, char_val in enumerate(row_val):
                if char_val == '@' or char_val == '+': # Player can be on a goal
                    return [c, r]
        return None # Should not happen in a valid level

    def getBoxes(self):
        boxes = []
        for r, row_val in enumerate(self.matrix):
            for c, char_val in enumerate(row_val):
                if char_val == '$': # Only boxes not on goals
                    boxes.append([c, r])
        return boxes
    
    def getAllBoxesAndGoals(self):
        """Returns positions of all boxes ($ or *) and all goals (. or * or +)."""
        boxes = []
        goals = []
        player_pos = None
        for r, row_val in enumerate(self.matrix):
            for c, char_val in enumerate(row_val):
                if char_val == '$' or char_val == '*':
                    boxes.append((c,r))
                if char_val == '.' or char_val == '*' or char_val == '+':
                    goals.append((c,r))
                if char_val == '@' or char_val == '+':
                    player_pos = (c,r)
        return player_pos, frozenset(boxes), frozenset(goals)

    def getSize(self):
        max_row_length = 0
        if not self.matrix:
            return [0,0]
        for row in self.matrix:
            row_length = len(row)
            if row_length > max_row_length:
                max_row_length = row_length
        return [max_row_length, len(self.matrix)]

    def resetLevel(self):
        """Resets the level to its original state."""
        self.matrix = copy.deepcopy(self.original_matrix)
        del self.matrix_history[:]
        # Player position might need to be re-found if not explicitly stored

    def getSolutionStep(self, step_index):
        """Returns a specific step from the stored solution path."""
        if 0 <= step_index < len(self.solution_path):
            return self.solution_path[step_index]
        return None

    def isSolved(self):
        """Checks if all boxes are on goals."""
        for r in range(len(self.matrix)):
            for c in range(len(self.matrix[r])):
                if self.matrix[r][c] == '$': # A box not on a goal
                    return False
        return True # All boxes must be '*' (box on goal)

